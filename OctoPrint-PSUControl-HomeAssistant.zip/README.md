# OctoPrint PSU Control - Home Assistant
Adds Home Assistant support to OctoPrint-PSUControl as a sub-plugin

## Setup
- Install the plugin using Plugin Manager from Settings
- Configure this plugin
- Select this plugin as a Switching and/or Sensing method in [PSU Control](https://github.com/kantlivelong/OctoPrint-PSUControl)

## Support
Help can be found at the [OctoPrint Community Forums](https://community.octoprint.org)